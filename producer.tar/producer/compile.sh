INPUT_FILE=$1

javac -cp "/kafka/kafka_2.13-3.7.0/libs/*":. $INPUT_FILE 

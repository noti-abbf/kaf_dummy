#!/bin/bash

export TOPIC_NAME=$1

echo "date : "`date`
echo ""
java -cp "/kafka/kafka_2.13-3.7.0/libs/*":. SimpleProducer $TOPIC_NAME 

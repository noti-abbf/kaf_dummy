import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.util.Arrays;
import java.util.Collections;
import java.util.Properties;

public class ConsumerGroupPartition {
    //public void receiveFromKafka() {
    public static void main(String[] args) {
	if(args.length == 0) {
	    System.out.println("Input 3 argument Group ID, Topic ID, partitionNumber");
	    System.out.println("ex) ./consumer_partition.sh GroupId TopicId PartitionNum");
	    return;
	}
	String groupId=args[0].toString();
	String topicId=args[1].toString();
	int partitionNum= Integer.parseInt(args[2]);

	Properties props = new Properties();
       	props.put("bootstrap.servers", "broker1:9092,broker2:9092,broker3:9092");
       	props.put("group.id", groupId);
       	props.put("enable.auto.commit", "false");
       	props.put("auto.offset.reset", "latest");
       	props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
       	props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");

       	KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(props);
	TopicPartition topicPartition = new TopicPartition(topicId,partitionNum); // topic partition
       	
	//consumer.subscribe(Arrays.asList(topicId));
	consumer.assign(Collections.singletonList(topicPartition));
       	try {
       	    while (true) {
                ConsumerRecords<String, String> records = consumer.poll(1000);
               	for (ConsumerRecord<String, String> record : records) {
	 		System.out.printf("Group ID: %s, Topic: %s, Partition: %s, Offset: %d, Key: %s, Value: %s \n",
                       	consumer.groupMetadata().groupId(), record.topic(), record.partition(), record.offset(), record.key(), record.value());
               	}
		consumer.commitSync();
           }
       	} finally {
             consumer.close();
	     System.out.println("=====END======");

          } 

    }
}

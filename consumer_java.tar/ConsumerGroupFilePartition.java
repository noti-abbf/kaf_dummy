import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Properties;

import java.util.Collections;
import java.util.Properties;

public class ConsumerGroupFilePartition {
    public static void main(String[] args) {
	if(args.length == 0) {
            System.out.println("Input 3 argument Group ID, Topic ID, partitionNumber");
            System.out.println("ex) ./consumer_partition.sh GroupId TopicId PartitionNum");
            return;
        }
        String groupId=args[0].toString();
        String topicId=args[1].toString();
        int partitionNum= Integer.parseInt(args[2]);
	    
	int checkpoint;
	boolean checkbool=false;
        Properties props = new Properties();
        props.put("bootstrap.servers", "broker1:9092,broker2:9092,broker3:9092");
        props.put("group.id", groupId);
        props.put("enable.auto.commit", "false");
        props.put("auto.offset.reset", "latest");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");

        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props);
	TopicPartition topicPartition = new TopicPartition(topicId,partitionNum); // topic partition
       
       
	// consumer.subscribe(Arrays.asList(topicId)); //topic partition automatically assign
        consumer.assign(Collections.singletonList(topicPartition));
	

        // using current time and change format : yyyymmdd_hhmmss 
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String formattedDate = LocalDateTime.now().format(formatter);

        //setting file path & name 
        String filePath = "/data/consumer/log/"+groupId+"_"+topicId+"_"+ "p_"+partitionNum+"_"+formattedDate + ".log";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
	    while (true) {
                ConsumerRecords<String, String> records = consumer.poll(1000);
		checkpoint=0;
                for (ConsumerRecord<String, String> record : records) {
                    checkpoint=1;
		    String recordString = String.format("Group ID: %s, Topic: %s, Partition: %s, Offset: %d, Key: %s, Value: %s, timestamp: %d \n",
                            consumer.groupMetadata().groupId(), record.topic(), record.partition(), record.offset(), record.key(), record.value(), record.timestamp());
		    //System.out.print(recordString);
		    
                    writer.write(recordString);
		    checkbool=true;
                }
		checkbool=false;
		if(checkbool==false && checkpoint==1) {
			writer.write ("----------------------------------\n");
		}
                writer.flush();
            	consumer.commitSync();
	    }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            consumer.close();
        }
    }
}


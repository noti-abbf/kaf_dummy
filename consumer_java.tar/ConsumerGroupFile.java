import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Properties;

public class ConsumerGroupFile {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Input Group ID and Topic ID");
            return;
        }
        String groupId = args[0];
        String topicId = args[1];
	int checkpoint;
	boolean checkbool=false;
        Properties props = new Properties();
        props.put("bootstrap.servers", "broker1:9092,broker2:9092,broker3:9092");
        props.put("group.id", groupId);
        props.put("enable.auto.commit", "false");
        props.put("auto.offset.reset", "latest");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");

        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props);
        consumer.subscribe(Arrays.asList(topicId));

        // using current time and change format : yyyymmdd_hhmmss 
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String formattedDate = LocalDateTime.now().format(formatter);

        //setting file path & name 
        String filePath = "/data/consumer/log/"+groupId+"_"+topicId+"_"+ formattedDate + ".log";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
	    while (true) {
                ConsumerRecords<String, String> records = consumer.poll(1000);
		checkpoint=0;
                for (ConsumerRecord<String, String> record : records) {
                    checkpoint=1;
		    String recordString = String.format("Group ID: %s, Topic: %s, Partition: %s, Offset: %d, Key: %s, Value: %s\n", 
	              consumer.groupMetadata().groupId(), record.topic(), record.partition(), record.offset(), record.key(), record.value(), record.timestamp());
		    //System.out.print(recordString);
		    
                    writer.write(recordString);
		    checkbool=true;
                }
		checkbool=false;
		if(checkbool==false && checkpoint==1) {
			writer.write ("----------------------------------\n");
		}
                writer.flush();
		consumer.commitSync();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            consumer.close();
            System.out.println("=====END======");
        }
    }
}


#!/bin/bash

export CONSUMER_GROUP_ID=$1
export TOPIC_NAME=$2

echo "date : "`date`
java -cp "/kafka/kafka_2.13-3.7.0/libs/*":. ConsumerGroup $CONSUMER_GROUP_ID $TOPIC_NAME


